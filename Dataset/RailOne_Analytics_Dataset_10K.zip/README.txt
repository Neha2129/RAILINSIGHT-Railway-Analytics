RailOne Passenger & Ticket Analytics — Dataset

IMPORTANT: This is a synthetic/anonymised college-project dataset.
It is NOT actual private RailOne customer data.

Files:
- tickets.csv: 10,000 simulated ticket transactions
- users.csv: 2,000 simulated users
- stations.csv: Western, Central, Harbour and Trans-Harbour reference data
- trains.csv: train reference data
- payments.csv: payment transactions
- train_status.csv: sample/mock status history for the live-status dashboard

Suggested Power BI/MySQL relationships:
users[user_id] -> tickets[user_id]
trains[train_id] -> tickets[train_id]
tickets[ticket_id] -> payments[ticket_id]
stations[station_id] -> tickets[source_station_id]
stations[station_id] -> tickets[destination_station_id]
trains[train_id] -> train_status[train_id]
stations[station_id] -> train_status[current_station_id]

For a genuine real-time component, replace/supplement train_status.csv with an
authorised/current railway API or public live feed.
